class Asset{
  static const assetImage = 'assets/images';
  static const logoImage = '$assetImage/logo.png';
  static const noPhotoImage = '$assetImage/no_photo.jpg';
  static const pinBikerImage = '$assetImage/pin_biker.png';
  static const pinMarkerImage = '$assetImage/pin_marker.png';
  static const pinCurrentImage = '$assetImage/pin_current.png';
}