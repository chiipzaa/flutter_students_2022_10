class AppSetting {
  static const String username = 'username';
  static const String token = 'token';
}